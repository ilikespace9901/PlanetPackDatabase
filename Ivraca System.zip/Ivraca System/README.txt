All textures are self-made in ibisPaint, excluding  gradients which were made using https://coolors.co

Started 26.10.25

v1.0 - Main system
v1.1 - Minor bodies and integration into Sagralis
v1.2 - Visuals (backgrounds, really)
v1.3 - Distant brown dwarf
