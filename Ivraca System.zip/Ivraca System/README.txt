All textures are self-made in ibisPaint, excluding  gradients which were made using https://coolors.co

Started 26.10.25

v1.0 - Adds the main system
v1.1 - Minor bodies and more moons
v1.2 - Visuals (how do i do day night cycles lol)
v1.3 - Distant brown dwarf
v1.4 - Visuals for BD planets
